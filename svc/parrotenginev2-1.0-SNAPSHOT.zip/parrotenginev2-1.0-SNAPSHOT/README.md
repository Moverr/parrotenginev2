# parrotenginev2
Installation 
- Framework : Play 2.8x

<br/>

![Scala CI](https://github.com/Moverr/parrotenginev2/workflows/Scala%20CI/badge.svg?branch=master)
<link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
 

<br/>
<ol>
<li><strong>USER</strong>
    <ul>
    <li>Login <i class="fa fa-spinner fa-spin fa-3x fa-fw"></i></li>
    <li>Register </li>
     <li>JWT Token </li>
     <li>Social Auth </li>
    </ul>

</li>
 
  <li>Organisation 
<uL>
 <li>Create Organization
 <li>List Organizations
 <li>Archive Organization
 
 </UL>
</li>
  <li>Station </li>
  <li>Employee </li>
  <li>Visitor </li>
  <li>Firebase </li>
  <li>Notification </li>
 
</ol>
